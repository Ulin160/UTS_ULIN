/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wahdahulinnafisah_17090019_4d_uts_oop;

/**
 *
 * @author User
 */
public class WahdahUlinNafisah_17090019_4D_UTS_OOP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
