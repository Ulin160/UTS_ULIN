package project.model;

public class Smartphone {

    private String MerekSmartphone;
    private String IdBarang;
    private String Seri;

    public Smartphone() {}

    public Smartphone(String MerekSmartphone, String IdBarang, String Seri) {
        this.MerekSmartphone = MerekSmartphone;
        this.IdBarang = IdBarang;
        this.Seri = Seri;
    }

    @Override
    public boolean equals(Object obj) {
        Smartphone spn = (Smartphone) obj;
        if(this.IdBarang.equals(spn.getIdBarang())) return true;
        else return false;
    }

    @Override
    public String toString() {
        return "[ " + MerekSmartphone + ", " + IdBarang + ", " + Seri + " ];";
    }

    public String getMerekSmartphone() {
        return MerekSmartphone;
    }

    public void setMerekSmartphone(String MerekSmartphone) {
        this.MerekSmartphone = MerekSmartphone;
    }

    public String getIdBarang() {
        return IdBarang;
    }

    public void setIdBarang(String IdBarang) {
        this.IdBarang = IdBarang;
    }

    public String getSeri() {
        return Seri;
    }

    public void setSeri(String Seri) {
        this.Seri = Seri;
    }



    

}