package project;

import java.util.LinkedList;
import java.util.Scanner;
import project.model.*;
import project.service.*;

public class Aplikasi {

    private static Scanner scanner;
    private static SmartphoneService service;
    private static String MerekSmartphone;
    private static String IdBarang;
    private static String Seri;

    public static void main(String args[]) {
        int opsi = 0;
        scanner = new Scanner(System.in);
        service = new SmartphoneService();

        do {
            cetakMenu();
            opsi = scanner.nextInt();
            switch(opsi) {
                case 1 :
                  modulAdd();
                  break;
                case 2 :
                  ubahData(); break;
                case 3 :
                  hapusData(); break;
                case 4 :
                  tampilData();
                  break;
            }
        } while(opsi != 0);

    }

    private static void cetakMenu() {
        System.out.println("\n\n");
        System.out.println("APLIKASI PEREKAMAN DATA MAHASISWA");
        System.out.println("1. Tambah Data");
        System.out.println("2. Ubah Data");
        System.out.println("3. Hapus Data");
        System.out.println("4. Tampilkan data");
        System.out.println("-----------");
        System.out.println("0. KELUAR");
        System.out.println("\n");
        System.out.print("Pilihan > ");
    }

    private static void modulAdd(){
        String nim, nama, kelas;

        System.out.println("--- tambah data ---");
        System.out.print("MerekSmartphone : "); 
        scanner = new Scanner(System.in);
        MerekSmartphone = scanner.nextLine();
        System.out.print("IdBarang : ");
        IdBarang = scanner.nextLine();
        System.out.print("Seri : ");
        Seri = scanner.nextLine();
        service.addData(new Smartphone(MerekSmartphone, IdBarang, Seri));
        
    }

    private static void tampilData() {
        LinkedList<Smartphone> result = (LinkedList<Smartphone>) service.getAllData();

        int i=1;
        for(Smartphone spn : result) {
            System.out.println("data ke-" + i++);
            System.out.println("  MerekSmartphone: " + spn.getMerekSmartphone());
            System.out.println("  IdBarang: " + spn.getIdBarang());
            System.out.println("  Seri: " + spn.getSeri());
        }
    }

    private static void ubahData() {
        String MerekSmartphone, IdBarang, Seri;

        System.out.println("--- perubahan data ---");
        System.out.print("MerekSmartphone : "); 
        scanner = new Scanner(System.in);
        MerekSmartphone = scanner.nextLine();
        System.out.print("IdBarang : ");
        IdBarang = scanner.nextLine();
        System.out.print("Seri : ");
        Seri = scanner.nextLine();
        service.updateData(new Smartphone(MerekSmartphone, IdBarang, Seri));
    }

    private static void hapusData() {
        String IdBarang;

        System.out.println("--- hapus data ---");
        System.out.print("IdBarang : ");
        scanner = new Scanner(System.in);
        IdBarang = scanner.nextLine();
        service.deleteData(new Smartphone(IdBarang, null, null));
    }

}