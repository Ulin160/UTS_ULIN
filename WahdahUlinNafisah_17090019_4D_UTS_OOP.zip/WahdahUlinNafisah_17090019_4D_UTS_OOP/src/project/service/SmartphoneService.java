package project.service;

import java.util.LinkedList;
import java.util.List;

import project.model.Smartphone;

public class SmartphoneService {

    private static List<Smartphone> data = new LinkedList<>();

    public void addData(Smartphone spn) {
        data.add(spn);
        System.out.println("data telah tersimpan");
    }

    public void updateData(Smartphone spn) {
        int result = data.indexOf(spn);
        
        if(result >= 0) {
            data.set(result, spn);
            System.out.println("data telah diubah");
        } else {
            System.out.println("data yang ingin diubah tidak ditemukan");
        }
    }

    public void deleteData(Smartphone spn) {
        int result = data.indexOf(spn);

        if(result >= 0) {
            data.remove(result);
            System.out.println("data telah terhapus");
        } else {
            System.out.println("Data yang ingin dihapus tidak ada");
        }
    }

    public List<Smartphone> getAllData() {
        return data;
    }

}